package cn.itcast_06;

/*
 * �û������ӿ�
 */
public interface UserDao {
	public abstract void add();

	public abstract void delete();

	public abstract void update();

	public abstract void find();
}