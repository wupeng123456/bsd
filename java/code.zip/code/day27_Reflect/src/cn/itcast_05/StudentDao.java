package cn.itcast_05;

public interface StudentDao {
	public abstract void login();

	public abstract void regist();
}
