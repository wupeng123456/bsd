package cn.itcast_05;

public class StudentDaoImpl implements StudentDao {

	@Override
	public void login() {
		System.out.println("��¼����");
	}

	@Override
	public void regist() {
		System.out.println("ע�Ṧ��");
	}

}
