package cn.itcast_02;

public interface Phone {
	public abstract void call();
}
